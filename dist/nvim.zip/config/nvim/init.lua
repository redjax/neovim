-- Detect platform
local platform = require("config.platform")

require("config")
require("plugins.manager")

-- Set your active theme here
-- \ Managed by Themery plugin for this config
-- vim.cmd.colorscheme("catppuccin-mocha")
