-- File encoding
if vim.g.platform == "windows" then
  vim.opt.fileformats = { "dos", "unix" }
end