-- Clipboard settings
require('config.options.clipboard')
-- Encoding settings
require('config.options.encoding')
-- Folding settings
require('config.options.folding')
-- GUI settings
require('config.options.gui')
-- Indentation settings
require('config.options.indent')
-- Search settings
require('config.options.search')
-- State settings
require('config.options.state')
-- Terminal settings
require('config.options.terminal')
-- UI settings
require('config.options.ui')
-- Window settings
require('config.options.window')
