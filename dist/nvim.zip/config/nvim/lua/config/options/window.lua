-- Window splitting
vim.opt.splitright = true
vim.opt.splitbelow = true
