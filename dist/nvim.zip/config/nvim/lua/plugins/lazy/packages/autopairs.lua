-- Autopairs https://github.com/windwp/nvim-autopairs

return {
    enabled = true,
    'windwp/nvim-autopairs',
    event = "InsertEnter",
    lazy = true,
    opts = {}
}