-- Bbye buffer management https://github.com/moll/vim-bbye

return {
    enabled = true,
    "moll/vim-bbye"
}