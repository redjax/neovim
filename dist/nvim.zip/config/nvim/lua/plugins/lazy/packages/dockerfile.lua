-- Dockerfile https://github.com/ekalinin/Dockerfile.vim

return {
    enabled = true,
    "ekalinin/Dockerfile.vim"
}