-- Fidget https://github.com/j-hui/fidget.nvim

return {
    enabled = true,
    "j-hui/fidget.nvim",
    -- Load on a general event, or use "LspAttach" for LSP-only
    event = "VeryLazy",
    opts = {},
}