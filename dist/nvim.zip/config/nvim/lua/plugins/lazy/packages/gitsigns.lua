-- Gitsigns lewis6991/gitsigns.nvim

return {
    enabled = true,
    'lewis6991/gitsigns.nvim',
    -- event = "VeryLazy",
    cmd = "Gitsigns",
    opts = {},
    -- config = function()
    -- 	require('gitsigns').setup()
    -- end
}