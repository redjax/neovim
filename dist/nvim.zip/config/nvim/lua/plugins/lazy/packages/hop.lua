-- Hop motions https://github.com/smoka7/hop.nvim

return {
    enabled = true,
    'smoka7/hop.nvim',
    version = "*",
    opts = {
        keys = 'etovxqpdygfblzhckisuran'
    }
}