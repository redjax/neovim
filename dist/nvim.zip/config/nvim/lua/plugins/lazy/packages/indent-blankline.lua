-- Indent blankline https://github.com/lukas-reineke/indent-blankline.nvim

return {
    enabled = true,
    "lukas-reineke/indent-blankline.nvim",
    main = "ibl",
    ---@module "ibl"
    ---@type ibl.config
    opts = {},
}