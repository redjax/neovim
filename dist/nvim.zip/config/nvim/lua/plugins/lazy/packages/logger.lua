-- Logger https://github.com/rmagatti/logger.nvim

return {
    enabled = true,
    "rmagatti/logger.nvim",
    lazy = true
}