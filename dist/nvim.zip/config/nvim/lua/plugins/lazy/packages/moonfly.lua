-- Moonfly theme https://github.com/bluz71/vim-moonfly-colors

return {
    enabled = true,
    "bluz71/vim-moonfly-colors",
    name = "moonfly",
    lazy = false,
    priority = 1000
}