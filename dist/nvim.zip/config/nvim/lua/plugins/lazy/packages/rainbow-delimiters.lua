-- Rainbow Delimiters https://github.com/HiPhish/rainbow-delimiters.nvim

return {
    enabled = true,
    "HiPhish/rainbow-delimiters.nvim",
    -- Or "BufReadPost" if you want it earlier
    event = "VeryLazy",
}
