-- Catppuccin themes https://github.com/catppuccin/nvim

return {
    enabled = true,
    "catppuccin/nvim",
    name = "catppuccin",
    lazy = false,
    priority = 1000,
}