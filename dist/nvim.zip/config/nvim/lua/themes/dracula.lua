-- Dracula theme https://github.com/Mofiqul/dracula.nvim

return {
    enabled = true,
    "Mofiqul/dracula.nvim",
    name = "dracula",
    lazy = false,
    priority = 1000,
}