-- Everforest theme https://github.com/sainnhe/everforest

return {
    enabled = true,
    "sainnhe/everforest",
    name = "everforest",
    lazy = false,
    priority = 1000,
}