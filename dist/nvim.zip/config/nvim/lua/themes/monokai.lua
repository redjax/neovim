-- Monokai theme https://github.com/tanvirtin/monokai.nvim

return {
    enabled = true,
    "tanvirtin/monokai.nvim",
    name = "monokai",
    lazy = false,
    priority = 1000,
}