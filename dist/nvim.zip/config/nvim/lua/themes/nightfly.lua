-- Nightfly theme https://github.com/bluz71/vim-nightfly-colors

return {
    enabled = true,
    "bluz71/vim-nightfly-colors",
    name = "nightfly",
    lazy = false,
    priority = 1000,
    config = function()
        -- Optional: set nightfly options here
        -- vim.g.nightflyItalics = false
        -- vim.cmd.colorscheme("nightfly")
    end,
}
