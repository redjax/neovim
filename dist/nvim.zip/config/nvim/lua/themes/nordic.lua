-- Nordic theme https://github.com/AlexvZyl/nordic.nvim

return {
    enabled = true,
    'AlexvZyl/nordic.nvim',
    name = "nordic",
    lazy = false,
    priority = 1000,
}
