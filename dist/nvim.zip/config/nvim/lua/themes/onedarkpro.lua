-- Onedark Pro theme https://github.com/olimorris/onedarkpro.nvim

return {
    enabled = true,
    "olimorris/onedarkpro.nvim",
    name = "onedarkpro",
    lazy = false,
    priority = 1000,
}