-- Oxocarbon theme https://github.com/nyoom-engineering/oxocarbon.nvim

return {
    enabled = true,
    "nyoom-engineering/oxocarbon.nvim",
    name = "oxocarbon",
    lazy = false,
    priority = 1000,
}