-- Palenightfall theme https://github.com/JoosepAlviste/palenightfall.nvim

return {
    enabled = true,
    "JoosepAlviste/palenightfall.nvim",
    name = "palenightfall",
    lazy = false,
    priority = 1000,
}