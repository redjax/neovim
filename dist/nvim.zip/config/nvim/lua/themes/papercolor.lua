-- Papercolor theme https://github.com/NLKNguyen/papercolor-theme

return {
    enabled = true,
    "NLKNguyen/papercolor-theme",
    name = "papercolor",
    lazy = false,
    priority = 1000,
}