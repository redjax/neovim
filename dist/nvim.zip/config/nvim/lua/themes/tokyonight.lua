-- TokyoNight themes https://github.com/folke/tokyonight.nvim

return {
    enabled = true,
    "folke/tokyonight.nvim",
    name = "tokyonight",
    lazy = false,
    priority = 1000,
}