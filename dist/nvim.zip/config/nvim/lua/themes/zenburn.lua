-- Zenburn theme https://github.com/jnurmine/Zenburn

return {
    enabled = true,
    "jnurmine/Zenburn",
    name = "zenburn",
    lazy = false,
    priority = 1000,
}
